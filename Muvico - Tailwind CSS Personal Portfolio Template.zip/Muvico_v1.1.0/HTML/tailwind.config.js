const colors = require('tailwindcss/colors')
const plugin = require('tailwindcss/plugin')

module.exports = { 
    plugins: [

    ],
}